	</div>
</div><!-- #container -->
<div id="footer">
	<div class="pads">
		<ul id="menu-bottom" class="clearfix">
<div id="footer-b">
<br />Lorem ipsum dolor sit amet, consectetur<br />adipiscing elit. Sed non risus. Suspendisse<br />lectus tortor, dignissim sit amet,<br />adipiscing nec, ultricies sed, dolor.<br />Cras elementum ultrices diam.
</div>
		</ul>
	</div>
	<div class="footerlinks">
<!-- #ici code -->
	</div>
</div><!-- #footer -->
<?php wp_footer() ?> <!-- #NE PAS SUPPRIMER cf. codex wp_footer() -->
</body>
</html>