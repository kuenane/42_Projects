<?php get_header() ?>

<div id="content_index">
<div id="title_white">
<br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />
BIENVENUE À LA MAISON
</div>
<div id="subtitle_white">
Louez des logements uniques auprès d'hôtes locaux dans 190+ pays.
</div>
<div id="idbtn_grey">
<a class="btn_grey" href="http://wp.local.42.fr:8080/?page_id=18">Mode d'emploi</a>
</div>
		<div id="blocsearch"> <?php include('searchform.php'); ?></div></div>
<div id="title_grey">
Juste pour le weekend
</div>
<div id="subtitle_grey">
Découvrez de nouveaux lieux inspirants près de chez vous.
</div>
<br /> <br /> <br />
<table><tbody>
<tr><td><p style="text-align:right"><a href=""><img src="http://wp.local.42.fr:8080/wp-content/themes/42born2code/images/ny.jpg"></a></p>
</td><td><p style="text-align:center"><a href=""><img src="http://wp.local.42.fr:8080/wp-content/themes/42born2code/images/paris.jpg"></a></p>
</td><td><p style="text-align:left"><a href=""><img src="http://wp.local.42.fr:8080/wp-content/themes/42born2code/images/rome.jpg"></a></p>
</td></tr>
</tbody></table>
<?php get_footer() ?>