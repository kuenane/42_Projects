<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clefs secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur 
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C'est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d'installation. Vous n'avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'db_database');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'root');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', 'azerty');

/** Adresse de l'hébergement MySQL. */
define('DB_HOST', 'localhost:3306');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8');

/** Type de collation de la base de données. 
  * N'y touchez que si vous savez ce que vous faites. 
  */
define('DB_COLLATE', '');

/**#@+
 * Clefs uniques d'authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant 
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n'importe quel moment, afin d'invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|%qFEDlCuD5/iZc`dY|r&76?{leqmEvb5m$6! -],um.b)laD>^PtCxE5Qm|tM;O');
define('SECURE_AUTH_KEY',  '}9@~|f~Lr>d` )Wj7N@iV=xQHswugoM J+oxFkk z|tf+Gg?;p56vxX$CsdS~WeN');
define('LOGGED_IN_KEY',    'iSqsH|/|PI3o6ad|Ba++MVBp9s/I{|O7`.K-ka5=.;]GIlXc$AD]MD:%-nXt*74P');
define('NONCE_KEY',        'C[s=,>yWvDfWmV_6aUevH1B1tU/!B:V,Kba$b/j*b#5&D0U.0piU]e3wO[tc4*MQ');
define('AUTH_SALT',        'V:f5`cP 46+N2sB~Y0VNlHRFN)>OxvBM{P1#TUs#`b!; /E`MOI&V{JG%=>SOv:)');
define('SECURE_AUTH_SALT', 'n-`!5b%Ea?-yr4as|Y`7+Z.pQ yNEb{R%`1vGU#$9wo0iYeI%B2XU_PL@kt?*8OE');
define('LOGGED_IN_SALT',   '-I)2C4C[zylt/VjwM2iWlnf9n~4FQaTYN?VwD_c!&@6*aj+P;};rV5U#-zq<Ybgw');
define('NONCE_SALT',       '42o8^t6npZa&z:<K, e[KR+ce!LsGF++S5hqH:|~wp}SNA{G[sCtF$9TgFm4{[m^');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique. 
 * N'utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés!
 */
$table_prefix  = 'wp_';

/** 
 * Pour les développeurs : le mode deboguage de WordPress.
 * 
 * En passant la valeur suivante à "true", vous activez l'affichage des
 * notifications d'erreurs pendant votre essais.
 * Il est fortemment recommandé que les développeurs d'extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de 
 * développement.
 */ 
define('WP_DEBUG', false); 

/* C'est tout, ne touchez pas à ce qui suit ! Bon blogging ! */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');